import streamlit as st
from streamlit_option_menu import option_menu
import pickle

load_model_diabetes=pickle.load(open("C:/Users/91995/Downloads/diabetes_trained_model.sav",'rb'))
load_model_heart_disease =  pickle.load(open('C:/Users/91995/OneDrive/Documents/Multiple disease web app/heart_disease_data.sav','rb'))
load_model_perkinsons=pickle.load(open('C:/Users/91995/OneDrive/Documents/Multiple disease web app/perkinsons_disease.sav','rb'))

with st.sidebar:
    select = option_menu('Multiple disease prediction system using machine learning',
                        ['Diabetes Prediction',
                        'Heart disease prediction',
                        'Perkinsons Disease prediction'],
                        icons=['activity','heart','person'],
                        default_index=0)
    
if(select=='Diabetes Prediction') :
    st.title('Diabetes Prediction using ML')

     # Get user inputs
    col1,col2=st.columns(2)
    with col1:
        Pregnancies = st.text_input('Number of pregnancies')
    with col1:
        Glucose = st.text_input('Glucose Level')
    with col1:
        BloodPressure = st.text_input('Blood Pressure Level')
    with col2:
        SkinThickness = st.text_input('Skin Thickness')
    with col2:
        Insulin = st.text_input('Level of Insulin')
    with col2:
        BMI = st.text_input('BMI Level')
    with col1:
        DiabetesPedigreeFunction = st.text_input('Diabetes Pedigree Function')
    with col2:
        Age = st.text_input('Age')

    diabetes_diagnosis = ''

    if st.button('Diabetes Test Result'):
        # Convert inputs to appropriate numerical types
        try:
            input_data = [float(Pregnancies), float(Glucose), float(BloodPressure), float(SkinThickness),
                          float(Insulin), float(BMI), float(DiabetesPedigreeFunction), float(Age)]
            diabetes_diagnosis = load_model_diabetes.predict([input_data])
            if diabetes_diagnosis[0] == 0:
                st.success("The person is non-diabetic")
            else:
                st.success("The person is diabetic")
        except ValueError:
            st.error("Please enter valid numerical values")  

if(select=='Heart disease prediction') :
    st.title('Heart disease prediction using ML')
    col1,col2=st.columns(2)
    with col1 :
        age= st.text_input("Age")
    with col1:
        sex=st.text_input("Sex")
    with col1:
        cp=st.text_input("Chest Pain type")
    with col1:
        trestbps=st.text_input("Resting Blood Pressure in mm Hg")
    with col1:
        chol=st.text_input("Serum Cholesterol in mg/dl")
    with col1:
        fbs=st.text_input("Fasting Blood Sugar")
    with col2:
        restecg= st.text_input("Resting Electrocardiographic results")
    with col2:
        thalach=st.text_input("Maximum Heart Rate Achieved")
    with col2:
        exang=st.text_input("Exercise induced angina")
    with col2:
        oldpeak=st.text_input("ST depression induced by exercise relative to rest")
    with col2:
        slope= st.text_input("The slope of the peak exercise ST segment")
    with col2:
        ca=st.text_input("Number of major vessels (0-3) colored by flourosopy")
    with col2:
        thal=st.text_input("Thalassemia:0 = normal; 1 = fixed defect; 2 = reversable defect")
    heart_diagnosis = ''

    if st.button('Heart Disease Test Result'):
        # Convert inputs to appropriate numerical types
        try:
            input_data = [float(age), float(sex), float(cp), float(trestbps),
                          float(chol), float(fbs), float(restecg), float(thalach),float(exang),float(oldpeak),float(slope),float(ca),float(thal)]
            heart_diagnosis = load_model_heart_disease.predict([input_data])
            if heart_diagnosis[0] == 0:
                st.success("The person is healthy")
            else:
                st.success("The person has unhealthy heart")
        except ValueError:
            st.error("Please enter valid numerical values")

if(select=='Perkinsons Disease prediction') :
    st.title('Perkinsons Disease prediction using ML')

    col1,col2=st.columns(2)

    with col1 :
        name= st.text_input("Name")
    with col1:
        MDVP_Fo_Hz=st.text_input("MDVP:Fo(Hz)")
    with col1:
        MDVP_Fhi_Hz=st.text_input(" MDVP:Fhi(Hz)")
    with col1:
        MDVP_Flo_Hz=st.text_input("MDVP:Flo(Hz)")
    with col1:
        MDVP_Jitter_percent=st.text_input("MDVP:Jitter(%)")
    with col1:
        MDVP_Jitter_Abs=st.text_input(" MDVP:Jitter(Abs)")
    with col2:
        MDVP_RAP= st.text_input("MDVP:RAP")
    with col2:
        MDVP_PPQ=st.text_input("MDVP:PPQ")
    with col2:
        Jitter_DDP=st.text_input("Jitter:DDP")
    with col2:
        MDVP_Shimmer=st.text_input("MDVP:Shimmer")
    with col2:
        MDVP_Shimmer_dB= st.text_input("MDVP:Shimmer(dB)")
    with col2:
        Shimmer_APQ3=st.text_input("Shimmer:APQ3")
    with col2:
        Shimmer_APQ5=st.text_input("Shimmer:APQ5")
    with col1:
        MDVP_APQ=st.text_input("MDVP:APQ")
    with col1:
        Shimmer_DDA=st.text_input("Shimmer:DDA")
    with col1:
        NHR=st.text_input("NHR")
    with col2:
        HNR= st.text_input("HNR")
    with col2:
        RPDE=st.text_input("RPDE")
    with col2:
        DFA=st.text_input("DFA")
    with col2:
        spread1=st.text_input("spread1")
    with col2:
        spread2= st.text_input("spread2")
    with col2:
        D2=st.text_input("D2")
    with col2:
        PPE=st.text_input("PPE")
    
    perkinsons_diagnosis = ''

    if st.button('Perkinson Disease Test Result'):
        # Convert inputs to appropriate numerical types
        try:
            input_data = [float(MDVP_Fo_Hz), float(MDVP_Fhi_Hz), float(MDVP_Flo_Hz), float(MDVP_Jitter_percent),
                          float(MDVP_Jitter_Abs), float(MDVP_RAP), float(MDVP_PPQ), float(Jitter_DDP),
                          float(MDVP_Shimmer), float(MDVP_Shimmer_dB), float(Shimmer_APQ3), float(Shimmer_APQ5),
                          float(MDVP_APQ), float(Shimmer_DDA), float(NHR), float(HNR), float(RPDE),
                          float(DFA), float(spread1), float(spread2), float(D2), float(PPE)]
            perkinsons_diagnosis = load_model_perkinsons.predict([input_data])
            if perkinsons_diagnosis[0] == 0:
                st.success("The person is healthy")
            else:
                st.success("The person has Perkinsons disease")
        except ValueError:
            st.error("Please enter valid numerical values")


    